const help = (prefix) => {
	return `


 ╔╦══ ⋆ ⋆ ✦ ⋅ ✩ ⋅ ✦ ⋆ ⋆ ══╦╗
           ♠ 𝙆𝙀𝙉 𝘿𝙊𝙈𝙄𝙉𝘼 ♠
 ╚╩══ ⋆ ⋆ ✦ ⋅ ✩ ⋅ ✦ ⋆ ⋆ ══╩╝


📌 Prefix:  *「${prefix} 」*

🔎 Status: *「 Online 」



╭─────═「 *𝙆𝙀𝙉 𝘽𝙊𝙏* 」
│data de criação 12/01/2021
│instagran: [ OFF ]
│chat: em breve 🤭
│youtube: em breve 🤭
│whatzapp: no final dos comandos
╰────────



╭─────⊣〘 𝗙𝗜𝗚𝗨𝗥𝗜𝗡𝗛𝗔 〙
│
│      
├═➥ *${prefix}sticker* ou *${prefix}stiker*
│➛ converter imagem/gif/vídeo em │adesivo
│
├═➥ *${prefix}sticker nobg* ou *${prefix}stiker nobg*
│➛converter imagem em adesivo removendo o fundo
│
├═➥ *${prefix}toimg*
│➛ converter adesivo em imagem
│
├═➥ *${prefix}tsticker* ou *${prefix}tstiker*
│➛ converter texto em adesivo
│
╭─────⊣〘 𝗠𝗘𝗠𝗘 〙
│
├═➥ *${prefix}meme*
│➛ mandar imagens aleatórias de meme [inglês]
│
├═➥ *${prefix}memeindo*
│➛ mandar imagens aleatórias de meme [indo]
│
╭─────⊣〘 𝗢𝗨𝗧𝗥𝗢𝗦 〙 
│
├═➥ p*${preftx}gtts*
│➛ converter texto em fala/áudio
│➛ *${prefix}gtts [cc] [text]*\n
│➛ exemplo : *${prefix}gtts ja On2-chan*\n
│
├═➥ *${prefix}loli*
│➛mandar imagens aleatórias de loli
│
├═➥ *${prefix}nsfwloli*
│➛mandar imagens aleatórias de nsfw loli
│
├═➥ *${prefix}url2img*
│➛ tirar screenshots da web
│➛ *${prefix}url2img [tipe] [url]*\n
│
├═➥ *${prefix}simi*
│➛ responder sua mensagem por simi
│➛ *${prefix}simi sua mensagem*\n
│
├═➥ *${prefix}ocr*
│➛ pegar o texto da foto e lhe enviar
│
├═➥ *${prefix}wait*
│➛ útil em : pesquisar sobre o anime por imagem [ Que anime é este/que ]
│
├═➥ *${prefix}setprefix*
│➛ alterar o prefixo do bot
│➛ esemplo : *${prefix}setprefix ?*
│➛ Usado somente pelo proprietário do bot\n
│
╭─────⊣〘 𝗚𝗥𝗨𝗣𝗢 〙
│      
├═➥ *${prefix}linkgroup*
│➛ enviar o link do grupo
│
├═➥ *${prefix}marcar*
│➛ marcar todos os membros do grupo, incluindo administradores
│➛ Você precisa ser administrador do grupo\n
│
├═➥ *${prefix}simih 1* para ativar o modo simi  
├═➥*${prefix}simih 0* 
│➛para desativar o modo simih
│➛ Você precisa ser administrador do grupo\n
│
├═➥ *${prefix}add*
│➛ adicionar membro ao grupo
│➛ *${prefix}add 5585xxxxx*\n
│➛ o bot precisa ser admin!\n
│
├═➥ *${prefix}kick*
│➛ remover membros do grupo
│➛ *${prefix}kick e o @da pessoa*\n
│➛ Você precisa ser admin e o bot │também
│
├═➥ *${prefix}promote*
│➛ tornar membro do grupo um administrador
│➛ *${prefix}promote e o @da pessoa*\n
│➛ Você precisa ser admin e o bot │também
│
├═➥ *${prefix}demote*
│➛ tornar o administrador um │membro comum
│➛ *${prefix}demote e o @da pessoa*\n
 Você precisa ser admin e o bot │também
│
╰─────═「 *𝙆𝙀𝙉 𝘽𝙊𝙏* 」


╭─────⊣〘 𝗠𝗘𝗡𝗨 𝗚𝗘𝗥𝗔𝗟 〙
│
├➤ *${prefix}help1* ♔
│
╰────────── ✾ ────────── 



    ╔─━━━━━━░★░━━━━━━─╗
  
           FEITO POR *KEN*
              DUVIDAS? 👇
  
          wa.me/5579999076521

    ╚─━━━━━━░★░━━━━━━─╝`
}

exports.help = help







